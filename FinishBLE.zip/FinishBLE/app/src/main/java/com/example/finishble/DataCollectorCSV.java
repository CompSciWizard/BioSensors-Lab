package com.example.finishble;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import androidx.annotation.RequiresApi;
import java.io.IOException;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
public class DataCollectorCSV {
    private static List<Float> dataPoints;
    private static boolean isCollectingData;
    private static long startTime;

    public static void startDataCollection() {
        dataPoints = new ArrayList<>();
        isCollectingData = true;
        startTime = System.currentTimeMillis() / 1000;
    }

    public static void stopDataCollection(ContentResolver contentResolver) {
        isCollectingData = false;
        long stopTime = System.currentTimeMillis() / 1000;
        long elapsedTime = stopTime - startTime;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            saveDataToCSV(contentResolver, elapsedTime);
        }
    }

    public static void addDataPoint(float value) {
        if (isCollectingData) {
            dataPoints.add(value);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    public static void saveDataToCSV(ContentResolver contentResolver, long elapsedTime) {
        if (dataPoints.isEmpty()) {
            System.out.println("No data points to save.");
            return;
        }

        String fileName = generateFileName();
        String displayName = fileName + ".csv";

        ContentValues contentValues = new ContentValues();
        contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, displayName);
        contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "text/csv");

        Uri externalUri = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL);
        Uri itemUri = contentResolver.insert(externalUri, contentValues);

        try (OutputStream outputStream = contentResolver.openOutputStream(itemUri)) {
            if (outputStream != null) {
                StringBuilder csvData = new StringBuilder();
                csvData.append("Time (s),Data\n");

                DecimalFormat decimalFormat = new DecimalFormat("#.00");

                float timeIncrement = elapsedTime / (float) dataPoints.size();

                float currentTime = 0.0f;
                for (float value : dataPoints) {
                    String formattedTime = decimalFormat.format(currentTime);
                    String formattedValue = decimalFormat.format(value);

                    csvData.append(formattedTime).append("s,").append(formattedValue).append("\n");
                    currentTime += timeIncrement;
                }

                outputStream.write(csvData.toString().getBytes());
                outputStream.flush();
                System.out.println("Data saved to CSV file: " + displayName);
            }
        } catch (IOException e) {
            System.err.println("Error writing data to CSV file: " + e.getMessage());
        }
    }

    private static String generateFileName() {
        SimpleDateFormat dateFormat = (SimpleDateFormat) SimpleDateFormat.getInstance();
        String timestamp = dateFormat.format(new Date());
        return "data_" + timestamp;
    }

}


