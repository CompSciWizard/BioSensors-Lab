package com.example.finishble;

import android.os.Handler;
import android.os.Looper;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class GraphsUtil {


    private static double minY = 0;
    private static double maxY = 6;
    private static long startTime = System.currentTimeMillis() / 1000;

    private static final int MAX_BUFFER_SIZE = 1000; // Maximum number of data points to store
    private static final long PLOT_INTERVAL = 250; // Plot interval in milliseconds
    private static final int DATA_BUNDLE_SIZE = 500; // Number of data points to bundle

    // Map to hold the graph series for each sensor
    private static final Map<String, LineGraphSeries<DataPoint>> sensorGraphMap = new HashMap<>();

    // Map to hold the data buffer for each sensor
    private static final Map<String, List<DataPoint>> sensorDataBufferMap = new HashMap<>();

    public static void createGraphSeries(GraphView graphView, String sensorKey) {
        LineGraphSeries<DataPoint> mSeries = new LineGraphSeries<>();
        graphView.addSeries(mSeries);
        graphView.getViewport().setScalable(true);
        graphView.getViewport().setScrollable(true);
        graphView.getViewport().setYAxisBoundsManual(true);
        graphView.getViewport().setMinY(GraphsUtil.getMinY());
        graphView.getViewport().setMaxY(GraphsUtil.getMaxY());

        graphView.getGridLabelRenderer().setHorizontalLabelsVisible(false);

        sensorGraphMap.put(sensorKey, mSeries);
        sensorDataBufferMap.put(sensorKey, new ArrayList<>());

        startPlotTimer(sensorKey);
    }

    public static void addDataPoint(String sensorKey, float value) {
        double currentTime = System.currentTimeMillis() / 1000.0;
        double x = (currentTime - startTime) * 0.1; // Adjust the x-axis units

        DataPoint dataPoint = new DataPoint(x, value);
        List<DataPoint> dataBuffer = sensorDataBufferMap.get(sensorKey);

        if (dataBuffer == null) {
            // Initialize the data buffer if it doesn't exist
            dataBuffer = new ArrayList<>();
            sensorDataBufferMap.put(sensorKey, dataBuffer);
        }

        dataBuffer.add(dataPoint);

        if (dataBuffer.size() >= MAX_BUFFER_SIZE) {
            discardOldestDataPoints(sensorKey);
        }

        if (dataBuffer.size() >= DATA_BUNDLE_SIZE) {
            plotDataPoints(sensorKey);
        }
    }

    private static void discardOldestDataPoints(String sensorKey) {
        List<DataPoint> dataBuffer = sensorDataBufferMap.get(sensorKey);
        int numPointsToRemove = dataBuffer.size() - MAX_BUFFER_SIZE;
        if (numPointsToRemove > 0) {
            dataBuffer.subList(0, numPointsToRemove).clear();
        }
    }

    private static void startPlotTimer(String sensorKey) {
        ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
        executor.scheduleAtFixedRate(() -> plotDataPoints(sensorKey), 0, PLOT_INTERVAL, TimeUnit.MILLISECONDS);
    }

    private static void plotDataPoints(String sensorKey) {
        List<DataPoint> dataBuffer = sensorDataBufferMap.get(sensorKey);
        LineGraphSeries<DataPoint> mSeries = sensorGraphMap.get(sensorKey);
        if (dataBuffer != null && mSeries != null) {
            final DataPoint[] dataPoints = dataBuffer.toArray(new DataPoint[0]);
            dataBuffer.clear();
            getMainHandler().post(() -> {
                for (DataPoint dataPoint : dataPoints) {
                    mSeries.appendData(dataPoint, true, Integer.MAX_VALUE / 100);
                }
            });
        }
    }

    private static final class MainHandlerHolder {
        static final Handler mainHandler = new Handler(Looper.getMainLooper());
    }

    public static void setYAxisBounds(double minValue, double maxValue) {
        minY = minValue;
        maxY = maxValue;
    }

    public static double getMinY() {
        return minY;
    }

    public static double getMaxY() {
        return maxY;
    }

    private static Handler getMainHandler() {
        return MainHandlerHolder.mainHandler;
    }

}

