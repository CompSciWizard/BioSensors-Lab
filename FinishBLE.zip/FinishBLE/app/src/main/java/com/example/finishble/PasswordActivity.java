package com.example.finishble;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class PasswordActivity extends AppCompatActivity {

    private EditText passwordEditText;
    private Button loginButton;
   private TextView errorTextView;

    private String correctPassword = "BLEUNF";

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password);

        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        errorTextView = findViewById(R.id.errorTextView);

        loginButton.setOnClickListener(v -> {
            String enteredPassword = passwordEditText.getText().toString();

            if (enteredPassword.equals(correctPassword)) {
                //Password is correct, navigate to the home activity
                Intent intent = new Intent(PasswordActivity.this, HomeActivity.class);
                startActivity(intent);
                finish();
            } else {
                //Password id incorrect, show an error message
                errorTextView.setText("Incorrect password");
            }
        });
    }
}
