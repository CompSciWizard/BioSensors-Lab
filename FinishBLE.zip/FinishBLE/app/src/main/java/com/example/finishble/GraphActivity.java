package com.example.finishble;

import android.os.Bundle;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.jjoe64.graphview.GraphView;

import java.util.ArrayList;
import java.util.List;

public class GraphActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);

        LinearLayout graphLayout = findViewById(R.id.graph_layout);

        List<String> sensorKeys = getSensorKeys();

        for(String sensorKey : sensorKeys){
            GraphView graphView = new GraphView(this);
            GraphsUtil.createGraphSeries(graphView, sensorKey);
            graphLayout.addView(graphView);
        }
    }
    // Implement this method based on how you store and manage the sensor data
    private List<String> getSensorKeys() {
        List<String> sensorKeys = new ArrayList<>();
        // Add the keys of the sensors for which you want to display the graphs
        sensorKeys.add("74cb87b3-798b-463c-a59c-c9e3127f90bb");
        sensorKeys.add("6ff0d9fd-2172-4c19-87ad-0ea25f2a5a12");
        // Add more keys as needed
        return sensorKeys;
    }

}
